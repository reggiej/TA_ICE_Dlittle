package com.icesoft.faces.env;

public interface Authorization {
    boolean isUserInRole(String role);
}
