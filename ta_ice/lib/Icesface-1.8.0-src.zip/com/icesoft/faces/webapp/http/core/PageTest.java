package com.icesoft.faces.webapp.http.core;

public interface PageTest {

    boolean isLoaded();
}
