package com.icesoft.faces.webapp.http.common;

public interface ResponseHandler {

    void respond(Response response) throws Exception;
}
