package com.icesoft.faces.webapp.http.common;

import java.io.File;

public interface FileLocator {

    File locate(String path);
}
