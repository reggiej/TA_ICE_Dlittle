package com.icesoft.faces.webapp.http.common;

public interface MimeTypeMatcher {

    String mimeTypeFor(String extesion);
}
